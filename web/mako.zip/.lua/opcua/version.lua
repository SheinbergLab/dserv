return {
  ApplicationUri = "urn:realtimelogic:opcua",
  ProductUri = "http://realtimelogic.com",
  ProductName = "RealTimeLogic OPCUA",
  ApplicationName = "RealTimeLogic OPCUA",
  ManufacturerName = "RealTimeLogic",
  Version = "0.7.4",
  BuildNumber = "96"
}
